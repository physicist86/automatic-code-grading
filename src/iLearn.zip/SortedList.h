// Course: CS 14 Spring 2012
// 
// First Name: Jane
// Last Name: Doe
// UCR Username: jdoe001
// UCR Email Address: jdoe001.university.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: John Smith
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#ifndef SORTED_LIST_H
#define SORTED_LIST_H

#include <fstream>
#include <string>
#include <iostream>

class SortedList
{
  friend struct ListNode;

public:
  virtual void insert(const std::string &) {exit(1);}
  // Precondition: array is not full
  // Postcondition: word is in proper location in array
  virtual bool find(const std::string &) const {exit(1);}
  // Precondition: none
  // Postcondition: Return value is true if word is in array, false otherwise
  virtual void remove(const std::string &) {exit(1);}
  // Precondition: none
  // Postcondition: word is no longer in array, and there are no gaps between
  // words in the array
  void batch
  (void (SortedList::*op)(const std::string &), const std::string & filename);
  // Precondition: filename refers to plain-text file of words
  // Postcondition: op is called on all the words in the file
  virtual ~SortedList() {}

  virtual bool isEmpty() const {exit(1);}
  // Precondition: none
  // Postcondition: Return value is true if list has no words
  virtual bool isFull() const {exit(1);}
  // Precondition: none
  // Postcondition: Return value is true if cannot hold more words
  //virtual void print() const;

  static size_t getNumAllocation() {return NumAllocations;}
  // Precondition: none
  // Postcondition: Return value is current number of strings or ListNodes

protected:
  static size_t NumAllocations;   // number of words currently allocated
};

inline bool lessThan(std::string lhs, std::string rhs)
// Precondition: none
// Postcondition: Return true if rhs follows lhs lexicographycally,
// case insensitive
{ 
  const int ASCII_a = 97;
  std::string lower_lhs = lhs;
  std::string lower_rhs = rhs;

  for(unsigned i = 0; i < lhs.size(); i++)
      if(lhs[i] < ASCII_a) lower_lhs[i] += 32;
     
  for(unsigned i = 0; i < rhs.size(); i++)
      if(rhs[i] < ASCII_a) lower_rhs[i] += 32;

  return (lower_lhs < lower_rhs);
}

#endif
