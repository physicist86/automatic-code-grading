// Course: CS 14 Spring 2012
// 
// First Name: Jane
// Last Name: Doe
// UCR Username: jdoe001
// UCR Email Address: jdoe001.university.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: John Smith
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#include "SortedList.h"
#include "SortedArrayList.h"
#include "SortedLinkedList.h"
#include "Timer.h"
#include <iostream>

using namespace std;

int main()
{
    //SortedArrayList* list = new SortedArrayList[45500];
    SortedLinkedList* list = new SortedLinkedList;
    //list->print();
     list->batch(&SortedList::insert, string("sample.txt"));
    cout << "** List: ";
    list->printList(); 
    
    //list->batch(&SortedList::remove, string("sample.txt"));
    //list->print();

    return 0;
}
