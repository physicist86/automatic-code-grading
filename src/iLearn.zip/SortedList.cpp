// Course: CS 14 Spring 2012
// 
// First Name: Jane
// Last Name: Doe
// UCR Username: jdoe001
// UCR Email Address: jdoe001.university.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: John Smith
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#include "Timer.h"
#include "SortedList.h"
#include <fstream>

size_t SortedList::NumAllocations = 0;

using namespace std;

void SortedList::batch
(void (SortedList::*op)(const string &), const string & filename)
{
  // *** REPLACE WITH YOUR IMPLEMENTATION ***
  // a call to the func pointer "op" passed in as an argument to this func
  // is made by: "(this->*op)(word);" where "word" is a string
  
  ifstream in;
  in.open(filename.c_str());
  string word;
  Timer t;
  t.start();
  while(in >> word)
  {
	  (this->*op)(word);
  }
  in.close();
  t.stop();
  cout << t.elapsedTime() << endl;
}
