// Course: CS 14 Spring 2012
// 
// First Name: Jane
// Last Name: Doe
// UCR Username: jdoe001
// UCR Email Address: jdoe001.university.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: John Smith
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#include "Timer.h"
#include "SortedLinkedList.h"

using namespace std;

SortedLinkedList::SortedLinkedList() : head(NULL) {}

SortedLinkedList::SortedLinkedList(const SortedLinkedList & source)
: SortedList(), head(NULL)
{
  if(source.head == NULL) return;
  head = new ListNode(source.head->word);
  ListNode * thisNode = head;
  ListNode * sourceNode = source.head->next;
  while(sourceNode != NULL)
  {
    thisNode->next = new ListNode(sourceNode->word);
    thisNode = thisNode->next;
    sourceNode = sourceNode->next;
  }
}

SortedLinkedList::~SortedLinkedList() {destroy_list();}

SortedLinkedList & SortedLinkedList::operator =(const SortedLinkedList & rhs)
{
  if(this == &rhs) return *this;
  destroy_list();
  create_list(rhs);
  return *this;
}

void SortedLinkedList::insert(const string & word)
{
  int index = position(word);
  if(index == 0)
  {
	  head = makeNewNode(word, head);
	  return;
  }
  
  int counter = 0;
  for(ListNode* a = head; a != NULL; a = a->next)
  {
	  if(counter == index)
	  {
		  a->next = makeNewNode(word, a->next);
		  return;
	  }  
	  ++counter;
  }
}

bool SortedLinkedList::find(const string & word) const
{
  for(ListNode* a = head; a != NULL; a = a->next)
      if(a->word == word) return true;
  return false;
}

void SortedLinkedList::remove(const string & word)
{
    /*int index = indexOf(word);
    if(index == -1) return;
    ListNode* a = head;
    for(int i = 0; i < index-1; i++)
        a = a->next;
    ListNode* temp = a->next;
    a->next = a->next->next;
    delete temp;  */  
    exit(1);
}

void SortedLinkedList::create_list(const SortedLinkedList & source)
{
  if(source.head == NULL) return;
  head = new ListNode(source.head->word);
  ListNode * current = head->next;
  for(ListNode * p = source.head->next; p != NULL; p = p->next)
  {current = new ListNode(p->word); current = current->next;}
}

void SortedLinkedList::destroy_list()
{
  while(head!= NULL)
  {
    ListNode * current = head;
    head = head->next;
    delete current;
  }
}

int SortedLinkedList::position(const string& word) const
{
	int count = 0;
	for(ListNode* a = head; a != NULL; a = a->next)
	{
		if(a->word == word) return count;
		else if(lessThan(word,a->word)) return count;
		else if(lessThan(a->word, word) && a->next == NULL) return count + 1;
        else if(lessThan(a->word, word) && lessThan(word, a->next->word))
        {
			return count + 1;
		}
		else if(!lessThan(word, a->word) && a->next == NULL)
		{
			return count + 1;
		}
		else if(!lessThan(word, a->word) && lessThan(word, a->next->word))
		{
			return count + 1;
		}
	    ++count;
    }
    return count;
}

ListNode* SortedLinkedList::makeNewNode(string info, ListNode* newNext)
{
	++NumAllocations;
	return new ListNode(info, newNext);
}

int SortedLinkedList::indexOf(const string & word) const
{
	int count = 0;
	for(ListNode* a = head; a != NULL; a = a->next)
	{ 
	    if(a->word == word) return count;
	    else count++;
	}
	return count;
}

void SortedLinkedList::printList() const
{
	for(ListNode* a = head; a != NULL; a = a->next)
	{
		cout << a->word << " ";
	}
	cout << endl;
}
