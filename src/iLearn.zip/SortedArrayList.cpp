// Course: CS 14 Spring 2012
// 
// First Name: Jane
// Last Name: Doe
// UCR Username: jdoe001
// UCR Email Address: jdoe001.university.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: John Smith
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#include "Timer.h"
#include "SortedArrayList.h"

using namespace std;

SortedArrayList::SortedArrayList(size_t capacity)
: SortedList(), buf(NULL), capacity(capacity), size(0)
{create_array(capacity);}

SortedArrayList::SortedArrayList(const SortedArrayList & source)
: buf(NULL), capacity(source.capacity), size(source.size)
{
  create_array(capacity);
  for(size_t i = 0; i < size; ++i) buf[i] = source.buf[i];
}

SortedArrayList::~SortedArrayList() {destroy_array();}

SortedArrayList & SortedArrayList::operator =(const SortedArrayList & rhs)
{
  destroy_array();
  capacity = rhs.capacity;
  size = rhs.size;
  create_array(capacity);
  for(size_t i = 0; i != size; ++i) buf[i] = rhs.buf[i];
  return *this;
}

void SortedArrayList::insert(const string & word)
{
  //Find position, then copy down, then insert word  O(n)
  if(isFull()) return;
  int position = futurePosition(word);
  if(position != (int)size)
  {
	  copyDown(position);
	  buf[position] = word;
	  ++size;
  }
  else buf[size++] = word;
}

bool SortedArrayList::find(const string & word) const
{
  for(int i = 0; i < (int)size; i++)
      if(buf[i] == word) return true;
  return false;
}

void SortedArrayList::remove(const string & word)
{
  int index = indexOf(word);
  if(index == -1) return;
  else if(index != (int)(size -1)) copyUp(index);
  else 
  {
	  buf[index] = ""; 
	  --size;
  }
}

void SortedArrayList::create_array(size_t capacity)
{
  if(buf != NULL) destroy_array();
  if(capacity > 0) buf = new string[capacity];
  NumAllocations += capacity;
}

void SortedArrayList::destroy_array()
{
  if(buf != NULL) delete[] buf;
  NumAllocations -= capacity;
  buf = NULL;
}

int SortedArrayList::indexOf(const string & word) const
{for(int i = 0; i < int(size); ++i) if(buf[i] == word) return i; return -1;}


int SortedArrayList::futurePosition(const std::string& word) const
{
    if(size != 0)
	{
	  for(unsigned i = 0; i < size; i++)
	  {
		if(buf[i] == word) return i;
		else if(!lessThan(word, buf[i])&& i + 1 == size) return i+1;
        else if( lessThan( word, buf[i] ) ) return i;
        else if(lessThan(buf[i], word) && (i + 1) == size) return (i + 1);
      }
    }
    else return 0;
}

void SortedArrayList::copyDown(int position)
{
	for(int i = size; i > position; --i)
	    buf[i] = buf[i - 1];
}

void SortedArrayList::copyUp(int index)
{
	for(unsigned i = index; i < size; i++)
	    buf[i] = buf[i + 1];
}
/*
void SortedArrayList::print() const
{
	for(unsigned i = 0; i < size; i++)
	{
		cout << buf[i] << " ";
	}
	cout << endl;
}*/
